import React from 'react';


import '../App.css';

class About extends React.Component {
    render(){
        return(
            <div className="txt">
                About
            </div>
        )
    }
}
export default About;