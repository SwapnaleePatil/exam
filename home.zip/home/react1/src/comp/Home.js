import React from 'react';

import '../App.css';


class Home extends React.Component {
    render(){
        return(
            <div className="txt">
                Home
            </div>
        )
    }
}
export default Home;